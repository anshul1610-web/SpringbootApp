package com.yash.yotaapi.util;

/**
 * This enum is to store values available for field status.
 * @author nitin.chougale
 */
public enum Status {
	Active,
	Inactive;
}
