
package com.yash.yotaapi.exception;
/**
* Invalid credentials custom exception
*@author chandana.nemade
*/
public class InvalidCredentialsException extends RuntimeException {
 
    public InvalidCredentialsException(String message) {
        super(message);	
    }
}
 
