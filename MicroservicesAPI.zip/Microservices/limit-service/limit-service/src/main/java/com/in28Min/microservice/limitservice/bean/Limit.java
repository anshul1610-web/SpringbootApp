package com.in28Min.microservice.limitservice.bean;

public class Limit {

    private int maximum;
    private int minimum;

    public int getMaximum() {
        return maximum;
    }

    public void setMaximum(int maximum) {
        this.maximum = maximum;
    }

    public void setMinimum(int minimum) {
        this.minimum = minimum;
    }

    public int getMinimum() {
        return minimum;
    }

    public Limit(int maximum, int minimum) {
        this.maximum = maximum;
        this.minimum = minimum;
    }

    public Limit() {
    }
}
