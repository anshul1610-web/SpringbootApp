package com.in28Min.microservice.limitservice.comtroller;

import com.in28Min.microservice.limitservice.bean.Limit;
import com.in28Min.microservice.limitservice.configuration.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LimitControler {

    @Autowired
    private Configuration config;

    @GetMapping("/limits")
    public Limit retrievLimit(){
        return new Limit(config.getMaximum(),config.getMinimum());
    }

}
