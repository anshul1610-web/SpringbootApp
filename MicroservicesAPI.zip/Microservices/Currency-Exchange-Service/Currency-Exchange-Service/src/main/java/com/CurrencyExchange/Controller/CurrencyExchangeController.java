package com.CurrencyExchange.Controller;

import com.CurrencyExchange.CurrencyExchangeServiceApplication;
import com.CurrencyExchange.Model.CurrencyExchange;
import com.CurrencyExchange.Service.CurrencyExchangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
public class CurrencyExchangeController {

    @Autowired
    private Environment environment;
    @Autowired
    private CurrencyExchangeService currencyExchangeService;


    @GetMapping("/currency-exchange/from/{from}/to/{to}")
     public CurrencyExchange retrieveExchangeValue(
             @PathVariable String from,
             @PathVariable String to){

        String port = environment.getProperty("local.server.port");
        CurrencyExchange currencyExchange = currencyExchangeService.getValue(from,to);
        currencyExchange.setEnvironment(port);
        if(currencyExchange==null){
            throw  new RuntimeException("Unable to find Data for "+from+"to"+to);
        }
        return  currencyExchange;
    }
}
