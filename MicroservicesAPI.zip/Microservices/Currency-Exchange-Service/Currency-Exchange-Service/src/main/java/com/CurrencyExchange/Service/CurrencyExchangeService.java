package com.CurrencyExchange.Service;

import com.CurrencyExchange.Model.CurrencyExchange;
import com.CurrencyExchange.Repository.CurrencyExchangeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CurrencyExchangeService {

    @Autowired
    private CurrencyExchangeRepository currencyExchangeRepository;

    public CurrencyExchange getValue(String from,String to){
        CurrencyExchange currencyExchange = currencyExchangeRepository.findByFromAndTo(from, to);
        return currencyExchange;
    }
}
