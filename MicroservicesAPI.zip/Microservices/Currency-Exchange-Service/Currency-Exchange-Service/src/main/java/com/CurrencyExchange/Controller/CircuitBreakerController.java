package com.CurrencyExchange.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.service.annotation.GetExchange;

@RestController
public class CircuitBreakerController {

    @GetMapping("/sample")
    public String sampleApi(){
        ResponseEntity<String> forEntity = new RestTemplate()
                .getForEntity("http://localhost:8000/sample-url", String.class);
        return forEntity.getBody();
    }
}
